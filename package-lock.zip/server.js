var express=require('express');
var app=express();
var mongoose=require('mongoose');
var morgan=require('morgan')
var cors = require('cors')

//error handling start here
var connect = require('connect')
var errorhandler = require('errorhandler')
//error handing end here


var bodyParser=require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


//error handing from center start here
// var app = connect()
 
if (process.env.NODE_ENV === 'development') {
  // only use in development
  app.use(errorhandler())
}

//error handing from center end here


// var user_management=require('./routes/admin_customer_management')
var customer_table=require('./routes/customer_table')
var category=require('./routes/category')
var home=require('./routes/home')
var banner=require('./routes/banner')
var uploads=require('./routes/uploads')
var deals=require('./routes/deals')
var product=require('./routes/product')
var product_sku=require('./routes/product_sku')
var super_admin=require('./routes/super_admin')
var user_management=require('./routes/user_management')
var warehouse=require('./routes/warehouse')

// app.use('/user_management',user_management)
app.use('/customer_table',customer_table)
app.use('/category',category)
app.use('/home',home)
app.use('/banner',banner)
app.use('/uploads',uploads)
app.use('/deals',deals)
app.use('/product',product)
app.use('/product_sku',product_sku)
app.use('/super_admin',super_admin)
app.use('/user_management',user_management)
app.use('/warehouse',warehouse)

app.use(cors())

var port=4000;
mongoose.promis=global.promise;
var dburl_server="mongodb://35.154.163.39:27017/citygrocer";
// var dburl_server="mongodb://13.54.178.17:27017/city_grocer";
//  var dburl_server="mongodb://13.251.20.84:27017/city_grocer";
mongoose.connect(dburl_server,{useNewUrlParser:true},console.log('dbconnect'))
app.listen(port,()=>{console.log("server is running on port"+
port)})
