var express = require('express')
var product = require('../models/product')
var category = require('../models/category')
var product_sku = require('../models/product_sku')
var router = express.Router()

//****************************************************************************** */
//product_APIS
router.post('/product_add', (req, res) => {
    product.find((error, allproduct) => {
    product_sku.find((error, allproduct_sku) => {
    
    var product_id = allproduct.length + 1
    var sku_id = allproduct_sku.length 
    req.body._id = product_id
    
    var qry1 = { _id_category , name, pic, description, article_no, brand, best_price, mrp, selling_price, createBy, modifyBy }=req.body
    // var qry2 = {_id, product_id, size, stock, mrp, min_quantity, max_quantity, tax, selling_price, gst, pic }=req.body
    
    
    product.create(qry1, (err, allproduct) => {
    if(req.body.sku){
    for(var i=0; i<req.body.sku.length; i++){
    var sku_data ={
    _id:sku_id+i+1, 
    _id_product:product_id,
    size:req.body.sku[i].size,
    stock:req.body.sku[i].stock,
    mrp:req.body.sku[i].mrp,
    min_quantity:req.body.sku[i].min_quantity,
    max_quantity:req.body.sku[i].max_quantity,
    tax:req.body.sku[i].tax,
    selling_price:req.body.sku[i].selling_price,
    gst:req.body.sku[i].gst,
    pic:req.body.sku[i].pic,
    createBy:req.body.sku[i].createBy,
    modifyBy:req.body.sku[i].modifyBy
    } 
    console.log(sku_data);
    product_sku.create(sku_data, (err, allproduct_sku) => {
    if (!err) {
    return allproduct_sku;
    }
    });
    
    }
    if (err) {
    return allproduct_sku;
    } else {
    return res.json({
    status: 'success',
    message: 'successfully product is added'
    
    })
    }
    
    }
    
    // product_sku.create(qry2, (err, allproduct_sku) => {
    
    
    
    // if (err) {
    // res.json({
    // status: 'failed',
    // message: 'failed to display'
    // })
    // } else {
    // return res.json({
    // status: 'success',
    // message: 'successfully product is added',
    // product: [allproduct, allproduct_sku],
    // // sku: [allproduct_sku]
    // })
    // }
    // })
    })
    })
    })
    })

router.post('/delete', function (req, res) {
    let { _id } = req.body

    product.findOneAndDelete({ _id }, function (err, data) {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        } else {
            res.json({
                status: 'success',
                message: 'sucessfully  product is deleted',
                result: data
            });
        }
    })
})

router.get('/get', (req, res) => {
    // _id = req.params
    product.find({}, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        return res.json({
            status: 'success',
            message: 'successfully  product is displayed',
            result: data
        })
    })
})


router.post('/edit', (req, res, next) => {
    let { _id } = req.body
    product.findOneAndUpdate({ _id }, req.body, (err, data) => {
        product.findOne({ _id: _id }, (err, data) => {
            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
            else {
                res.json({
                    status: 'success',
                    message: 'successfully  product is updated',
                    result: data
                })
            }
        })
    })
})


//view by category name
router.post('/searchBy_product_name', function (req, res) {
    let { name: name } = req.body
    product.find({ name }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else {
            return res.json({
                status: 'success',
                message: 'successfully  product is displayed',
                result: data
            })
        }
    })
})


//view by product id
router.post('/product_findby_id', function (req, res) {
    let { _id: _id } = req.body
    let { _id: _id_product } = req.body
    var resultdata = [];
    var resultdata_sku = [];
    product.find({ _id }, (err, data) => {
        console.log(data[0]._doc);
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        } else {
            resultdata.push({
                _id: data[0]._doc_id,
                _id_category:data[0]._doc._id_category,
                best_price: data[0]._doc.best_price,
                mrp: data[0]._doc.mrp,
                selling_price: data[0]._doc.selling_price,
                pic: data[0]._doc.pic,
                name:data[0]._doc.name,
                price: data[0]._doc.price,
                image: data[0]._doc.image,
                description: data[0]._doc.description,
                article_no: data[0]._doc.article_no,
                brand: data[0]._doc.brand,
                createOn: data[0]._doc.createOn,
                modifyOn: data[0]._doc.modifyOn,
                skudata: resultdata_sku
            })
        }
        product_sku.find({ _id_product }, (error, skudata) => {
            console.log(skudata);
            for (var j = 0; j < skudata.length; j++) {
                console.log(skudata[j]._doc);
                resultdata_sku.push(skudata[j]._doc);
            }

            // console.log(resultdata);
            res.json({
                status: 'success',
                message: 'successfully  product is displayed',
                data: resultdata
            })
        });
    })
})


//product based on lowest category
router.post('/product_view_Onlowcat', function (req, res) {
    let { _id_subcategory } = req.body
   product.find({ _id_subcategory:_id_subcategory}, (err, data) => {
       if (err) {
           res.json({
               status: 'failed',
               message: 'failed to display'
           })
       }
       else if (!data) {
           res.json({
               status: "failed",
               message: "No data"
           })
       }
       else{
       res.json({
           status: 'success',
           message: 'successfully  low_category is displayed base on subcategory',
           result: data
       })
   }
   
   })
})
//view by category id
router.post('/findby_id', function (req, res) {
    let { _id: _id } = req.body
    product.find({ _id }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        } else {
            return res.json({
                status: 'success',
                message: 'successfully  product is displayed',
                result: data
            })
        }
    })
})



// router.post('/product_category_getall',function(req,res){
//     product.aggregate([
//         {
//           $lookup:
//           {
//             from: "catgeory",
//             localField: "_id",
//             foreignField: "_id_category",
//             as: "product_name",
//           },
//         },
//         // { $project: {"parent":1, "sub_categories":1, "_id":0} },

//       ],
//         function (err, result) {
//           if (err) {
//             res.send('Please contact admin');
//           } else {
//             res.send({
//               "Status": "Success",
//               "message": "Get Successfully", 
//               "products": result,

//             });
//           }

//         });


// })


// router.post('/populate',function(req,res){
//     product.findOne().populate('category').exec(function (err, category) {
//         if (err)  throw (err);
//         res.json(category)
//         console.log('The author is %s', category.products);


//       });
// })



module.exports = router