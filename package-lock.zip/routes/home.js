var express = require('express')
var mongoose = require('mongoose')
var category = require('../models/category')
var banner = require('../models/banner')
var product=require('../models/product')
var router = express.Router()

//var dburl1="mongodb://13.251.20.84:27017/city_grocer";  //fir server
//var dburl1="mongodb://localhost:27017/city_Grocer";     
// var dburl1="mongodb://13.251.20.84:27017/city_grocer";
 var dburl1="mongodb://13.251.20.84:27017/city_grocer";


//home page...
router.get("/home_page", function (req, res) {
    var category = []; //Create Empty order Object
    var banner = []; 
    var deals = [];
    var products=[];
    
    mongoose.connect(dburl1, function (err, db) {
       
        if (err) {
            throw err;
            
        }
        var Category = db.collection('categories');
        var Banner = db.collection('banners');
        var Deals = db.collection('deals');
        var Product=db.collection('products')

           Category.find().limit(10).toArray(function (err, result) {
            if (err) {
                throw err;
            } else {
                for (i = 0; i < result.length; i++) {
                    category[i] = result[i];
                }
            }
            Deals.find().limit(10).toArray(function (err, result) {
                if (err) {
                    throw err;
                } else {
                    for (i = 0; i < result.length; i++) {
                        deals[i] = result[i];
                    }
                }
                Product.find().limit(10).toArray(function (err, result) {
                    if (err) {
                        throw err;
                    } else {
                        for (i = 0; i < result.length; i++) {
                            products[i] = result[i];
                        }
        
                    }

            Banner.find().limit(10).toArray(function (err, result) {
                if (err) {
                    throw err;
                } else {
                    for (i = 0; i < result.length; i++) {
                        banner[i] = result[i];
                    }
                    var oMyOBject = {
                        "status": "success",
                        "message": "Get Successfully",
                        "result": {
                            
                            "category": category,
                            "banner": banner,
                            "deals": deals,
                            "products":products
                        }
                    };

                    res.json(oMyOBject);
                    db.close();   
                }
            })
        })
        })
    });
    
})


        });
    // })
// });

//home page...
router.get("/home_page1", function (req, res) {
    var category = []; //Create Empty order Object
    var banner = []; 
    var deals = [];
    
    mongoose.connect(dburl1, function (err, db) {
       
        if (err) {
            throw err;
        }
        var Category = db.collection('categories');
        var Banner = db.collection('banners');
        var Deals = db.collection('deals');

           Category.find().limit(10).toArray(function (err, result) {
            if (err) {
                throw err;
            } else {
                for (i = 0; i < result.length; i++) {
                    category[i] = result[i];
                }
            }
            Deals.find().limit(10).toArray(function (err, result) {
                if (err) {
                    throw err;
                } else {
                    for (i = 0; i < result.length; i++) {
                        deals[i] = result[i];
                    }
                }

            Banner.find().limit(10).toArray(function (err, result) {
                if (err) {
                    throw err;
                } else {
                    for (i = 0; i < result.length; i++) {
                        banner[i] = result[i];
                    }
                    var oMyOBject = {
                        "Status": "Success",
                        "message": "Get Successfully",
                        "result": {
                            
                            "category": category,
                            "banner": banner,
                            "deals": deals,
                        }
                    };

                    res.json(oMyOBject);
                    db.close();
                }
            })
        })
    });
    
})


        });
    // })
// });




module.exports = router

