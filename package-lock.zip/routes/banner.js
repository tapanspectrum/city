var express = require('express')
var banner = require('../models/banner')
var router = express.Router()
var morgan=require('morgan')
var upload=require('../models/banner')

function isValidJson(json) {
    try {
        JSON.parse(json);
        return true;
    } catch (e) {
        return false;
    }
}
router.post('/banner_add', (req, res) => {
    if(req.body!=null){
    banner.find((error, data) =>  {
        let recentDoc = data[data.length-1]
        recentDoc = recentDoc.toObject()
        let recentDocId = parseInt(recentDoc._id,10)
        req.body._id = recentDocId +1
        // var _id = allcategory.length + 1
        // req.body._id = _id
        var _id_category=req.body
        banner.create(_id_category, (err, data) => {
             if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            } else if(!data){
                res.json({ status: 'failed',})
               
            }
            else {
                return res.json({
                    status: 'success',
                    message: 'successfully  banner is added',
                    result: [data]
                })
            }   
        })
    })
}

else{
    res.json({message:"Failed"})
}
})

router.post('/banner_delete', function (req, res) {
    let { _id} = req.body
    
    banner.findByIdAndDelete({ _id}, function (err, data) {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        res.json({
            status: 'success',
            message: 'sucessfully  banner is deleted',
            result: [data]
        });
    })
})

router.get('/banner_get', (req, res) => {
    
    banner.find( (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        return res.json({
            status: 'success',
            message: 'successfully  banner is displayed',
            result: data
        })
    })
})


router.post('/banner_edit', (req, res, next) => {
    let { _id } = req.body
    banner.findOneAndUpdate({ _id }, req.body, (err, data) => {
        banner.findOne({ _id: _id }, (err, data) => {
            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
            else
            {
                res.json({
                    status: 'success',
                    message: 'successfully  banner is updated',
                    result: [data]
                })
            }
        })
    })
})


//view by category id
router.post('/searchBy_banner_id', function (req, res) {
    let { _id: _id } = req.body
    banner.find({ _id }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else{
        return res.json({
            status: 'success',
            message: 'successfully  banner is displayed',
            result: [data]
        })
    }
    })
})


module.exports=router