var express = require('express')
var deals=require('../models/deals')
var router = express.Router()

router.post('/add', (req, res) => {
    deals.find((error, alldeals) => {
        var _id = alldeals.length + 1
        req.body._id = _id
        deals.create(req.body, (err, data) => {
            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            } else {
                return res.json({
                    status: 'success',
                    message: 'successfully  deals is added',
                    result: [data]
                })
            }
        })
    })
})


router.get('/get', (req, res) => {
    _id = req.params
    deals.find(req.params, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        return res.json({
            status: 'success',
            message: 'successfully  deals is displayed',
            result: data
        })
    })
})


router.post('/delete', function (req, res) {
    let { _id} = req.body
    
    deals.findOneAndDelete({ _id}, function (err, data) {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else
        {
        res.json({
            status: 'success',
            message: 'sucessfully  deals is deleted', 
            result:data
        });
    }
    })
})

router.get('/get', (req, res) => {
    _id = req.params
    deals.find(req.params, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        return res.json({
            status: 'success',
            message: 'successfully  deals is displayed',
            result: data
        })
    })
})


router.post('/edit', (req, res, next) => {
    let { _id } = req.body
    deals.findOneAndUpdate({ _id }, req.body, (err, data) => {
        deals.findOne({ _id: _id }, (err, data) => {
            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
             else {
                res.json({
                    status: 'success',
                    message: 'successfully  deals is updated',
                     data
                })
            }
        })
    })
})


//view by category name
router.post('/searchBy_category_name', function (req, res) {
    let { name: name } = req.body
    category.find({ name }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else{
        return res.json({
            status: 'success',
            message: 'successfully  category is displayed',
            result: data
        })
    }
    })
})

//view by category id
router.post('/searchBy_deals_id', function (req, res) {
    let { _id: _id } = req.body
    deals.find({ _id }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else{
        return res.json({
            status: 'success',
            message: 'successfully  deals is displayed',
            result: data
        })
    }
    })
})

module.exports=router