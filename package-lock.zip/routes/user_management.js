var express = require('express')
var user_management = require('../models/user_management')
var router = express.Router()

router.post('/add', (req, res) => {
  
        user_management.find((error, data1) => {

        // var _id = allabout_us.length + 1
        // req.body._id = _id

            let recentDoc = data1[data1.length-1]
            recentDoc = recentDoc.toObject()
            let recentDocId = parseInt(recentDoc._id, 10)
            req.body._id = recentDocId +1

            user_management.create(req.body, (err, data) => {
            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            } else {
                return res.json({
                    status: 'success',
                    message: 'successfully  user_management is added',
                    result: data
                })
            }
        })      
    })
})


router.get('/get', (req, res) => {
    _id = req.params
    user_management.find(req.params, (err, data) => {
        if (err) {
            res.json({    
                status: 'failed',
                message: 'failed to display'
            })
        }
        return res.json({
            status: 'success',
            message: 'successfully  user_management is displayed',
            result: [data]
        })
    })
})


router.post('/delete', function (req, res) {
    let { _id} = req.body
    
    user_management.findByIdAndDelete({ _id}, function (err, data) {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        res.json({
            status: 'success',
            message: 'sucessfully  user_management is deleted',
            result: [data]
        });
    })
})




router.post('/edit', (req, res, next) => {
    let { _id } = req.body
    user_management.findOneAndUpdate({ _id }, req.body, (err, data) => {
        user_management.findOne({ _id: _id }, (err, data) => {
            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
            else
            {
                res.json({
                    status: 'success',
                    message: 'successfully  user_management is updated',
                    result: [data]
                })
            }
        })
    })
})

//view by category id
router.post('/searchBy_id', function (req, res) {
    let { _id: _id } = req.body
    user_management.find({ _id }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else{
        return res.json({
            status: 'success',
            message: 'successfully  user_management is displayed',
            result: [data]
        })
    }
    })
})

module.exports=router