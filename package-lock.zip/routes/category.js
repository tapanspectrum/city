var express = require('express')
var categories = require('../models/category')
var sub_categories = require('../models/sub_category')
var low_category = require('../models/low_category')
var router = express.Router()


//view by category and subcategory,lowest catg id
router.get('/category_subcategory_getall', function (req, res) {debugger
    let  _id
    categories.findOne({ _id }, (err, data) => {
        categories.aggregate([
            {

                $lookup:
                {
                    from: "sub_categories",
                    localField: "_id",
                    foreignField: "_id_category",
                    as: "sub_categories",
                }
            },
            {
                $lookup:
                {
                    from: "low_categories",
                    localField: "_id",
                    foreignField: "_id_subcategory",
                    as: "Lowest_sub_categories",
                }
            },
        ], function (err, result) {
            if (err) {
                res.send('Please contact admin');
            } else {
                res.send({
                    "status": "success",
                    "message": "Get Successfully",
                    "category": result,

                });
            }

        });
    })
})

//view by category and subcategory,lowest catg id
router.post('/category_sub_low', function (req, res) {
    let { _id: _id } = req.body
    categories.findOne({ _id }, (err, data) => {
        categories.aggregate([
            {

                $lookup:
                {
                    from: "sub_categories",
                    localField: "_id",
                    foreignField: "_id_category",
                    as: "sub_categories",
                }
            },

            {
                $unwind: "$sub_categories"
            },

            {
                $lookup:
                {
                    from: "low_categories",
                    localField: "_id",
                    foreignField: "_id_subcategory",
                    as: "Lowest_sub_categories",
                }
            },
           
        ], function (err, result) {
            if (err) {
                res.send('Please contact admin');
            } else {
                res.send({
                    "Status": "success",
                    "message": "Get Successfully",
                    "category": result,

                });
            }

        });
    })
})
//*************************** */category_APIS***********************************************
router.post('/add', (req, res) => {
    categories.find((error, data) => {
        
        // let recentDoc = data[data.length-1]
        // recentDoc = recentDoc.toObject()
        // let recentDocId = parseInt(recentDoc._id,10)
        // req.body._id = recentDocId +1

        var _id = data.length + 1
        req.body._id = _id

        categories.create(req.body, (err, data) => {

            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            // else if (!data) {
            //     res.json({
            //         status: "failed",
            //         message: "No data"
            //     })
            // }
            else {
                return res.json({
                    status: 'success',
                    message: 'successfully  category is added',
                    result: [data]
                })
            }
        })
    })
})


router.get('/get', (req, res) => {
    
    categories.find({parent:"0"}, (err, data) => {
    // category.find(req.params, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        return res.json({
            status: 'success',
            message: 'successfully  category is displayed',
            result: data
        })
    })
})



router.post('/delete', function (req, res) {
    let { _id } = req.body

    categories.findOneAndDelete({ _id }, function (err, data) {

        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data to delete"
            })
        }
        else
            res.json({
                status: 'success',
                message: 'sucessfully  category is deleted',
                result: data
            });
    })
})

router.post('/edit', (req, res, next) => {
    let { _id } = req.body
    categories.findOneAndUpdate({ _id }, req.body, (err, data) => {
        categories.findOne({ _id: _id }, (err, data) => {

            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
            else {
                res.json({
                    status: 'success',
                    message: 'successfully  category is updated',
                    data
                })
            }
        })
    })
})


//parent
router.post('/getsubcategory/view', function (req, res) {
    let { _id_category: _id_category } = req.body
    sub_categories.find({ _id_category }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data "
            })
        }
        else
        return res.json({
            status: 'success',
            message: 'successfully  sub_category is displayed',
            result: data
        })
    })
})
//********************************************************************************************** */




//view by category name
router.post('/searchBy_category_name', function (req, res) {
    let { name: name } = req.body
    categories.find({ name }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data "
            })
        }
        else
        return res.json({
            status: 'success',
            message: 'successfully  category is displayed',
            result: data
        })
    })
})

//view by category id
router.post('/searchBy_category_id', function (req, res) {
    let { _id: _id } = req.body
    categories.find({ _id }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if(!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else{
        return res.json({
            status: 'success',
            message: 'successfully  category is displayed',
            result: data
        })
    }
    })
})

//###################################################################
//subcategory APIS

router.post('/sub_add', (req, res) => {
    sub_categories.find((error, data) => {
        
        let recentDoc = data[data.length-1]
        recentDoc = recentDoc.toObject()
        let recentDocId = parseInt(recentDoc._id,10)
        req.body._id = recentDocId +1

        // var _id = data.length + 1
        // req.body._id = _id


        sub_categories.create(req.body, (err, data) => {

            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            // else if (!data) {
            //     res.json({
            //         status: "failed",
            //         message: "No data"
            //     })
            // }
            else {
                return res.json({
                    status: 'success',
                    message: 'successfully  sub_category is added',
                    result: [data]
                })
            }
        })
    })
})



router.post('/sub_view', function (req, res) {
    let { _id} = req.body
    sub_categories.findOne({ _id }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else
        return res.json({
            status: 'success',
            message: 'successfully  sub_category is displayed',
            result: data
        })
    
    })
})

router.post('/sub_delete', function (req, res) {
    let { _id } = req.body
    sub_categories.findOneAndDelete({ _id }, function (err, data) {

        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else
            res.json({
                status: 'success',
                message: 'sucessfully  sub_category is deleted',
                result: data
            });


    })

})

router.get('/sub_get', (req, res) => {
   
    sub_categories.find(req.params, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else {
        return res.json({
            status: 'success',
            message: 'successfully  sub_category is displayed',
            result: data
        })
    }
    })
})

router.post('/sub_edit', (req, res, next) => {
    let { _id } = req.body
    sub_categories.findOneAndUpdate({ _id }, req.body, (err, data) => {
        sub_categories.findOne({ _id }, (err, data) => {

            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
            else {
                res.json({
                    status: 'Success',
                    message: 'successfully  sub_category is updated',
                    data
                })
            }
        })
    })
})


//**************************************************************************************************************
//lowest category................
router.post('/low_add', (req, res) => {
    low_category.find((error, data) => {
        
        // let recentDoc = data[data.length-1]
        // recentDoc = recentDoc.toObject()
        // let recentDocId = parseInt(recentDoc._id,10)
        // req.body._id = recentDocId +1

        var _id = data.length + 1
        req.body._id = _id

        low_category.create(req.body, (err, data) => {

            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            // else if (!data) {
            //     res.json({
            //         status: "failed",
            //         message: "No data"
            //     })
            // }
            else {
                return res.json({
                    status: 'success',
                    message: 'successfully  lowest_category is added',
                    result: [data]
                })
            }
        })
    })
})

router.post('/low_view', function (req, res) {
     let { _id_subcategory } = req.body
    low_category.find({ _id_subcategory :_id_subcategory}, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else{
        res.json({
            status: 'success',
            message: 'successfully  low_category is displayed base on subcategory',
            result: data
        })
}
    
    })
})



//lowest category
router.post('/getlowcategory/view', function (req, res) {
    let { _id_subcategory: _id_subcategory } = req.body
    low_category.find({ _id_subcategory }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data "
            })
        }
        else
        return res.json({
            status: 'success',
            message: 'successfully  low_category is displayed',
            result: data
        })
    })
})


router.post('/low_edit', (req, res, next) => {
    let { _id } = req.body
    low_category.findOneAndUpdate({  _id }, req.body, (err, data) => {
        low_category.findOne({ _id }, (err, data) => {

    
    // category.findOneAndUpdate({ _id }, req.body, (err, data) => {
    //     category.findOne({ _id: _id }, (err, data) => {

            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
            else 
                res.json({
                    status: 'success',
                    message: 'successfully  low_category is updated',
                    data
                })
            
        })
    })
})
// })

router.get('/low_get', (req, res) => {
    low_category.find( (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }        
        else {
         res.json({
            status: 'success',
            message: 'successfully  low_category is displayed',
            result: data
        })
    }
    })
})


router.post('/low_delete', function (req, res) {
    let { _id } = req.body
    low_category.findOneAndDelete({ _id }, function (err, data) {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else
            res.json({
                status: 'success',
                message: 'sucessfully  low_category is deleted',
                result: data
            });
    })

})


//parent
router.post('/getlowcategory/view', function (req, res) {
    let { _id_subcategory: _id_subcategory } = req.body
    low_category.find({ _id_subcategory }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data "
            })
        }
        else
        return res.json({
            status: 'success',
            message: 'successfully  low_category is displayed',
            result: data
        })
    })
})


module.exports = router






// router.post('/all',function(req,res){

//     category.aggregate([
//         {
//           $lookup:
//           {
//             from: "categories",
//             localField: "_id",
//             foreignField: "parent",
//             as: "sub_categories",
//           },
//         },
//         // { $project: {"parent":1, "sub_categories.name":1, "_id":0} },

//       ],
//         function (err, result) {
//           if (err) {
//             res.send('Please contact admin');
//           } else {
//             res.send({
//               "Status": "Success",
//               "message": "Get Successfully",
//               "category": result,

//             });
//           }

//         });


// })