    var express = require('express')
var router = express.Router()
// var multer = require('multer');
var morgan = require('morgan');
var bodyParser = require('body-parser');
// var app = express();
const multer = require('multer');
const ejs = require('ejs');
const path = require('path');
var banner=require('../models/banner')

//...................................................
// Set The Storage Engine
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

// Init Upload
const upload_one = multer({
    storage: storage,
    limits: { fileSize: 100000000 },
    fileFilter: function (req, file, cb) {
        checkFileType(file, cb);
    }
}).single('myImage');

const upload_multi = multer({
    storage: storage,
    limits: { fileSize: 1000000 },
    fileFilter: function (req, file, cb) {
        checkFileType(file, cb);
    }
}).array('myImage', 20);


// Check File Typ
function checkFileType(file, cb) {
    // Allowed ext
    const filetypes = /jpeg|jpg|png|gif/;
    // Check ext
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
       return cb(null, true);
    // Check mime
    // const mimetype = filetypes.test(file.mimetype);
    //  if (mimetype && extname) {
    //      return cb(null, true);
    // } else {
    //      cb('Error: Images Only!');
    //  }
}


// Init app
const app = express();

// EJS
app.set('view engine', 'ejs');

// Public Folder
app.use(express.static('./public'));


//upload single file............
router.post('/upload_single', (req, res) => {
    upload_one(req, res, (err) => {
        if (err) {
            //   res.render('index', {
            res.json(err)
            //   });
        } else {
            if (req.file == undefined) {
                res.json({
                   "status": "failed",
                    "message": "failed to upload",
                });
            } else {
                res.json({
                     "status": "success",
                    "message": "uploaded successfully",
                    file: `uploads/${req.file.filename}`
                });
            }
        }
    });

})



//upload multiple file..................
 router.post('/upload_multi', (req, res) => {
    upload_multi(req, res, (err) => {
        if (err) {
            //   res.render('index', {
            res.json(err)
            //   });
        } else {
            if (req.files == undefined) {
                res.json({
                  "status": "failed",
                    "message": "failed to upload",
                });
            } else {
                res.json({
                    "status": "success",
                    "message": "uploaded successfully",
                    // file: `uploads/${req.files.filename}`
                });
            }
        }
    });
 });
//.............................................................



module.exports=router