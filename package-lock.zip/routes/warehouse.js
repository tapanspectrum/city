var express = require('express')
var warehouse = require('../models/warehouse')
var router = express.Router()

router.post('/warehouse_add', (req, res) => {
    if(req.body!=null){

    // warehouse.find((error, allcategory) => {
        warehouse.find((error, data) => {

        let recentDoc = data[data.length-1]
        recentDoc = recentDoc.toObject()
        let recentDocId = parseInt(recentDoc._id,10)
        req.body._id = recentDocId +1

        // var _id = allcategory.length + 1
        // req.body._id = _id
        // var _id_category=req.body

        var warehouse_num = "W-" + Math.floor(100 + Math.random() * 900)//generating referal code 
        req.body.warehouse_num = warehouse_num

        warehouse.create(req.body, (err, data) => {
             if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            } else if(!data){
                res.json({ status: 'failed', message: 'failed to add'})
               
            }
            else {
                return res.json({
                    status: 'success', 
                    message: 'successfully  warehouse is added',
                    result: [data]
                })
            }   
        })
    })
}
else{
    res.json({message:"Failed"})
}
})

router.post('/warehouse_delete', function (req, res) {
    let { _id} = req.body
    
    warehouse.findByIdAndDelete({ _id}, function (err, data) {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        res.json({
            status: 'success',
            message: 'sucessfully  warehouse is deleted',
            result: [data]
        });
    })
})

router.get('/get', (req, res) => {
    _id = req.params
    warehouse.find(req.params, (err, data) => {
        if (err) {
            res.json({    
                status: 'failed',
                message: 'failed to display'
            })
        }
        return res.json({
            status: 'success',
            message: 'successfully  warehouse is displayed',
            result: data
        })
    })
})

router.post('/warehouse_edit', (req, res, next) => {
    let { _id } = req.body
    warehouse.findOneAndUpdate({ _id }, req.body, (err, data) => {
        warehouse.findOne({ _id: _id }, (err, data) => {
            if (err) {
                res.json({
                    status: 'failed',
                    message: 'failed to display'
                })
            }
            else if (!data) {
                res.json({
                    status: "failed",
                    message: "No data"
                })
            }
            else
            {
                res.json({
                    status: 'success',
                    message: 'successfully  warehouse is updated',
                    result: [data]
                })
            }
        })
    })
})

//view by category id
router.post('/searchBy_warehouse_id', function (req, res) {
    let { _id: _id } = req.body
    warehouse.find({ _id }, (err, data) => {
        if (err) {
            res.json({
                status: 'failed',
                message: 'failed to display'
            })
        }
        else if (!data) {
            res.json({
                status: "failed",
                message: "No data"
            })
        }
        else{
        return res.json({
            status: 'success',
            message: 'successfully  warehouse is displayed',
            result: [data]
        })
    }
    })
})


module.exports=router