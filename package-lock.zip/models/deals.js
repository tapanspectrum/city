var mongoose = require('mongoose')


var schema = new mongoose.Schema({
    _id: String,
_id_category:String,

category_name:String,
 pic: String,
 mrp:String,
 selling_price:String,
 product_unit:String,
 artical_no:String,
 description:String,
 status:String,
 sold:String,



    
    createOn: { type: Date, default: Date.now },
    createBy: String,
    modifyOn: { type: Date, default: Date.now },
    modifyBy: String,

}, { versionKey: false })

module.exports = mongoose.model('deals', schema)