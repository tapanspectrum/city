var mongoose = require('mongoose')

var schema = new mongoose.Schema({
  
    _id: Number,
    firstname: String,
    lastname: String,
    email: String,
    mobilenumber: Number,
    password: String,
    pic: String,
    mobile_email:String

}, { versionKey: false })

module.exports = mongoose.model('super_admin', schema)