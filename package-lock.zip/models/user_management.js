var mongoose=require('mongoose')
var schema=new mongoose.Schema({
    _id:Number,
   
    firstname:String,
    email:String,
    mobilenumber:Number,
    status:String,
    
    // createOn: { type: Date, default: Date.now },
    // createBy: String,
    // modifyOn: { type: Date, default: Date.now },
    // modifyBy: String,
    
},{versionKey:false})
module.exports=mongoose.model('user_management',schema)