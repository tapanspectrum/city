var mongoose=require('mongoose')
var schema=new mongoose.Schema({
    _id:Number,

   name:String,
   description:String,  
   address:String,
   city:String,
   state:String,
   pincode:Number,
   parent:String,
   country:String,
warehouse_num:String,
    
    createOn: { type: Date, default: Date.now },
    createBy: String,
    modifyOn: { type: Date, default: Date.now },
    modifyBy: String,
    
},{versionKey:false})
module.exports=mongoose.model('warehouse',schema)