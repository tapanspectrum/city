var mongoose = require('mongoose')
// SALT_WORK_FACTOR = 10
// BCRYPT_SALT_ROUNDS =10
var bcrypt=require('bcrypt')
var schema = new mongoose.Schema({
    _id: String,


    // address:[{address:String,type: String}],
  // _id_product_id:String,
  status:String,
    gender:String,
    referal_code:String,
    mobilenumber: {type:String,minlength:'10',maxlength:'10',},
    email: String,        
    otp: String,
    mobile_email:String,
    password: String,
    email_mobilenumber: String,
    firstname: String,
    lastname: String,
    dob: String,

}, { versionKey: false })
// schema.pre('save', function(next){
//     var user = this;
//     if (!user.isModified('password')) return next();
 
//     bcrypt.genSalt(BCRYPT_SALT_ROUNDS, function(err, salt){
//         if(err) return next(err);
 
//         bcrypt.hash(user.password, salt, function(err, hash){
//             if(err) return next(err);
 
//             user.password = hash;
//             next();
//         });
//     });
// });
module.exports = mongoose.model('temp', schema)