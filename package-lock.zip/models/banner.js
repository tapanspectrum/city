var mongoose = require('mongoose')

var schema = new mongoose.Schema({
    // _id: Number,
    // _id_category:Number,
    // pic_web: String,
    // pic: String,
    // type: String,
    // target: String,
    // sequence: String,
    // block: String,

    _id: Number,
    // _id_category:String,
    pic_web: String,
    pic: String,
   
    table:String,
    sequence: String,
    block: String,
    table:String,
    banner_type:String,
    type: String,
    keyword:String,
    lowestcategory:String,
    sku_code:String,
    brand:String,
    target: String,

    
    createOn: { type: Date, default: Date.now },
    createBy: String,
    modifyOn: { type: Date, default: Date.now },
    modifyBy: String,

}, { versionKey: false })

module.exports = mongoose.model('banner', schema)