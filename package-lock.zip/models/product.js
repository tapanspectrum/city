var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var schema = new mongoose.Schema({
    _id: String,
    _id_subcategory:String,
    best_price:String,
    mrp:String,
    selling_price:String,
   pic:String,
    name: String,
    price: String,
    image: String,
    description:String,
    article_no:String,
    brand:String,
   
          


    
    createOn: { type: Date, default: Date.now },
    createBy: String,
    modifyOn: { type: Date, default: Date.now },
    modifyBy: String,           
    // category:[{ type: mongoose.Schema.Types.ObjectId, ref: 'category'}]
}, { versionKey: false })


module.exports = mongoose.model('product', schema)








